using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class quit_method : MonoBehaviour
{
   public void quit()
   {
    Application.Quit();
   }
}