using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class toggle_method : MonoBehaviour
{
   public GameObject shipComponent;
   private bool isVisible = true;

   public void Toggle()
   {
    if(isVisible)
    {
        shipComponent.SetActive(false);
        isVisible = false;
    }
    else
    {
       shipComponent.SetActive(true);
        isVisible = true; 
    }
   }
}
